#ifndef MAIN_HPP_INCLUDED
#define MAIN_HPP_INCLUDED

// Define code words for the GPIO pins
#define TRIG 20
#define ECHO 21
#define robotReset 12
#define servo 4

#define LCD_RS  22               //Register select pin
#define LCD_E   17               //Enable Pin
#define LCD_D4  25               //Data pin 4
#define LCD_D5  18               //Data pin 5
#define LCD_D6  24               //Data pin 6
#define LCD_D7  23               //Data pin 7

// Function declarations
void setup(void);                   //Function to configure the GPIO and devices for operation
int main(int argc, char** argv);

#endif // MAIN_HPP_INCLUDED

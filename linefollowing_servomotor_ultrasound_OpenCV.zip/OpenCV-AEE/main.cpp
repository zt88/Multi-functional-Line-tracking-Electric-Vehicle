// Include files for required libraries
#include <stdio.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <lcd.h>
#include <softPwm.h>

#include "opencv_aee.hpp"
#include "main.hpp"     // You can use this file for declaring defined values and functions

int lcd, robot;     // Variables to store numeric identifiers for wiringPi

void setup(void)
{
    //wiringPiSetup();    // Initialise the wiringPi library
    wiringPiSetupGpio();    // Initialise the wiringPi library with BCM numbering system

    pinMode(TRIG, OUTPUT);      // Setup the SR04 sensor pins
    pinMode(ECHO, INPUT);
    digitalWrite(TRIG, LOW);    // Prepare the trigger output of the SR04
    delay(50);

    pinMode(robotReset, OUTPUT);    // Setup the robotReset pin
    robot = serialOpen("/dev/serial0", 57600);  // Configure the serial port for the robot and bounce the reset pin
    digitalWrite(robotReset, LOW);
    delayMicroseconds(50);
    digitalWrite(robotReset, HIGH);

    lcd = lcdInit (2, 16, 4, LCD_RS, LCD_E, LCD_D4, LCD_D5, LCD_D6, LCD_D7, 0, 0, 0, 0); // Setup the LCD screen and display a message
    lcdPosition(lcd, 0,0);
    lcdPuts(lcd, "Hello World!");

    pinMode(servo, OUTPUT);     // Configure the output to the camera servo and set to a default position
    digitalWrite(servo, LOW);
    softPwmCreate(servo,15,200);   // (pin, initial position, range)
    delay(3000);
    softPwmStop(servo);

    setupCamera(320, 240);  // Enable the camera for OpenCV
}

int main( int argc, char** argv )
{
    setup();    // Call a setup function to prepare IO and devices

    cv::namedWindow("HSV Tester");   // Create a GUI window called HSV Tester

    int lowH = 0, highH = 1791220, lowS = 0, highS = 255, lowV = 0, highV = 255;    // Initialise some variables for HSV limits

    cv::createTrackbar("Low Hue", "HSV Tester", &lowH, 179, NULL);      // Create trackbar controls for each HSV limit
    cv::createTrackbar("High Hue", "HSV Tester", &highH, 179, NULL);

    cv::createTrackbar("Low Sat", "HSV Tester", &lowS, 255, NULL);
    cv::createTrackbar("High Sat", "HSV Tester", &highS, 255, NULL);

    cv::createTrackbar("Low Value", "HSV Tester", &lowV, 255, NULL);
    cv::createTrackbar("High Value", "HSV Tester", &highV, 255, NULL);


    while(1)    // Main loop to perform image processing
    {
        Mat frame = captureFrame(); // Capture a frame from the camera and store in a new matrix variable

        lowH = cv::getTrackbarPos("Low Hue", "HSV Tester");        // Update the variables with the trackbar setting
        highH = cv::getTrackbarPos("High Hue", "HSV Tester");
        lowS = cv::getTrackbarPos("Low Sat", "HSV Tester");
        highS = cv::getTrackbarPos("High Sat", "HSV Tester");
        lowV = cv::getTrackbarPos("Low Value", "HSV Tester");
        highV = cv::getTrackbarPos("High Value", "HSV Tester");

        Mat frameHSV;       // Convert the frame to HSV and apply the limits
        cv::cvtColor(frame, frameHSV, COLOR_BGR2HSV);
        cv::inRange(frameHSV, Scalar(lowH, lowS, lowV), Scalar(highH, highS, highV), frameHSV);

        Mat comparison;     // Join the two into a single image
        cvtColor(frameHSV, frameHSV, COLOR_GRAY2BGR);   // In range returns the equivalent of a grayscale image so we need to convert this before concatenation
        cv::hconcat(frame, frameHSV, comparison);//OPENCV_ABI_COMPATIBILITY

        cv::imshow("HSV Tester", comparison); //Display the image in the window

        int key = cv::waitKey(1);   // Wait 1ms for a keypress (required to update windows

        key = (key==255) ? -1 : key;    // Check if the esc key has been pressed
        if (key == 27)
            break;
	}

	closeCV();  // Disable the camera and close any windows

	return 0;
}




#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>

void init();

int main()
{
    init();
    int angle = 0;
    while(1)
    {
    scanf("%d", &angle);

    int i = 0;
    float x = 0;

    int k = 180;
    while(k--)
    {
    x = 11.11*i;
    if(angle<10)
    {
    for(int a=0;a<4;++a)
    {
    digitalWrite(16, HIGH);
    delayMicroseconds(500);
    digitalWrite(16, LOW);
    delayMicroseconds(19500);
    }
    }
    digitalWrite(16, HIGH);b
    delayMicroseconds(500+x);
    digitalWrite(16, LOW);
    delayMicroseconds(19500-x);
    if (i == angle)
    break;


    i++;
    }
    }
    return 0;
}


void init()
{
   wiringPiSetup();
   pinMode(16, OUTPUT);


}

//NOTE: you need to update the string info sent to the baseboard.
#include <wiringPi.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <wiringSerial.h>
#include <iostream>
void forward();
void reverse();
void stop();
using namespace std;
int robot;
int main()
{
//setup
    wiringPiSetupGpio();
    robot=serialOpen("/dev/ttyAMA0",57600);//open and initialize the serial port
    cout << robot<<endl;
//start
    forward();
    delay(5000);
    stop();
    reverse();
    delay(5000);
    stop();
//    serialPrintf(robot,"baffff+20%+20%+20%+20%");
//    delay(3000);
//    serialPrintf(robot,"Barrrr020,020,020,020");
//    delay(3000);

    serialClose(robot);
    return 0;
}

void stop(void)
{
    serialPrintf(robot,"#ha");
    delay(50);
}

void forward(void)
{
    serialPrintf(robot,"#baffff+20%+20%+20%+20%");
    delay(50);
//    serialPrintf(robot,"#S020,020");
//    delay(50);
    printf("F\n");
}

void reverse(void)
{
serialPrintf(robot,"#barrrr+20%+20%+20%+20%");
delay(50);
printf("R\n");
}

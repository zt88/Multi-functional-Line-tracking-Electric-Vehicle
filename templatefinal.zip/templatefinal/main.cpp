#include <stdio.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <lcd.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <string>
#include "opencv2/core.hpp"
#include "opencv2/features2d.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/calib3d.hpp"
#include "opencv2/xfeatures2d.hpp"
#include "opencv2/imgproc.hpp"
#include "imgproc.h"

#define Trig 5
#define Echo 6
//#define robotReset 12
#define servo 4

#define LCD_RS  22               //Register select pin
#define LCD_E   17               //Enable Pin
#define LCD_D4  25               //Data pin 4
#define LCD_D5  18               //Data pin 5
#define LCD_D6  24               //Data pin 6
#define LCD_D7  23

//#define leftMotorBaseSpeed 25//25
//#define rightMotorBaseSpeed 25//25
#define min_speed -75//75
#define max_speed 80

float ERROR=0, errorSum=0, errorOld=0;  // Variables for the PID loop
int leftMotorSpeed, rightMotorSpeed; // Variables to hold the current motor speed (+-100%)
int leftMotorBaseSpeed;//25
int rightMotorBaseSpeed;
//25
float Kp=0.5, Ki=0.01, Kd=0.5; //Ki=0.5 Kp=1.2//Kp=0.6,Ki=0.5,Kd=1.1//Kp=0.8,Ki=0.6,Kd=1.1//Kp=0.75 Ki=0.6 Kd=0.8
float output=0;
float linedist=0;
int sumblack,numblack,numpurple,numred,numyellow,numblue,numgreen,sumred,sumyellow,sumblue,sumgreen,numrec,sumrec;
int purplenumber=0;
bool purpleflag=1;
long startpurple=0,stoppurple=0;

using namespace std;
using namespace cv;

int robot;
int lcd;
int x, y;

VideoCapture cap(0);


Point findContourCentre(std::vector<cv::Point> contour)
{
    Moments foundRegion;    // Variables to store the region moment and the centre point
    Point centre;
    foundRegion = moments(contour, false);      // Calculate the moment for the contour
    centre.x = (foundRegion.m10/foundRegion.m00);  //Calculate the X and Y positions
    centre.y = (foundRegion.m01/foundRegion.m00);

    return centre;
}

Mat transformPerspective(std::vector<Point> boundingContour, Mat frame, int x_size, int y_size)
{
    if(boundingContour.size() != 4)
    {
        // Error the contour has too many points. Only 4 are allowed

        Mat emptyMat(y_size,x_size,CV_8UC1, Scalar(255));
        return emptyMat;
    }

    Mat symbol(y_size,x_size,CV_8UC1, Scalar(0));

    cv::Point2f symbolCorners[4], boundingCorners[4];      // Create (and populate) variables containing the corner locations for the transform
    symbolCorners[0] = Point2f(0,0);
    symbolCorners[1] = Point2f(symbol.cols - 1,0);
    symbolCorners[2] = Point2f(symbol.cols - 1,symbol.rows - 1);
    symbolCorners[3] = Point2f(0,symbol.rows - 1);

    Point contourCentre = findContourCentre(boundingContour);   // To populate the contour corners we need to check the order of the points

    int point1, point2, point3, point4;

    if(boundingContour[0].x > contourCentre.x)
    {
        if(boundingContour[0].y > contourCentre.y)
            point3 = 0;
        else
            point2 = 0;
    }
    else
    {
        if(boundingContour[0].y > contourCentre.y)
            point4 = 0;
        else
            point1 = 0;
    }

    if(boundingContour[1].x > contourCentre.x)
    {
        if(boundingContour[1].y > contourCentre.y)
            point3 = 1;
        else
            point2 = 1;
    }
    else
    {
        if(boundingContour[1].y > contourCentre.y)
            point4 = 1;
        else
            point1 = 1;
    }

    if(boundingContour[2].x > contourCentre.x)
    {
        if(boundingContour[2].y > contourCentre.y)
            point3 = 2;
        else
            point2 = 2;
    }
    else
    {
        if(boundingContour[2].y > contourCentre.y)
            point4 = 2;
        else
            point1 = 2;
    }

    if(boundingContour[3].x > contourCentre.x)
    {
        if(boundingContour[3].y > contourCentre.y)
            point3 = 3;
        else
            point2 = 3;
    }
    else
    {
        if(boundingContour[3].y > contourCentre.y)
            point4 = 3;
        else
            point1 = 3;
    }

    if(point1 + point2 + point3 + point4 != 6)
    {
        //Unable to reconstruct rectangle
        Mat emptyMat(y_size,x_size,CV_8UC1, Scalar(255));
        return emptyMat;
    }

/*
    boundingCorners[0] = boundingContour[point1];
    boundingCorners[1] = boundingContour[point2];
    boundingCorners[2] = boundingContour[point3];
    boundingCorners[3] = boundingContour[point4];
*/
    int dia_proc = 1; //with dilate pre-process
    int dia_size = 0;

    // if (dia_proc)
    //     dia_size = 4;

    //Bonding the contour with dialate pre-process
    boundingCorners[0].x = boundingContour[point1].x+dia_size;
    boundingCorners[0].y = boundingContour[point1].y+dia_size;
    boundingCorners[1].x = boundingContour[point2].x-dia_size;
    boundingCorners[1].y = boundingContour[point2].y+dia_size;
    boundingCorners[2].x = boundingContour[point3].x-dia_size;
    boundingCorners[2].y = boundingContour[point3].y-dia_size;
    boundingCorners[3].x = boundingContour[point4].x+dia_size;
    boundingCorners[3].y = boundingContour[point4].y-dia_size;

    Mat transformMatrix = cv::getPerspectiveTransform(boundingCorners, symbolCorners); // Calculate the required transform operation
    Mat transformedSymbol(y_size,x_size,CV_8UC1,Scalar(0));
    cv::warpPerspective(frame, transformedSymbol, transformMatrix, cv::Size(symbol.cols,symbol.rows));  // Perform the transformation

    return transformedSymbol;
}
void resizeCamera(int width, int height)
{
    cap.set(CAP_PROP_FRAME_WIDTH, width);
	cap.set(CAP_PROP_FRAME_HEIGHT, height);
}
float disMeasure(void)
 {
     struct timeval tv1;  //timevalÊÇtime.hÖÐµÄÔ¤¶¨Òå½á¹¹Ìå ÆäÖÐ°üº¬Á½¸öÒ»¸öÊÇÃë£¬Ò»¸öÊÇÎ¢Ãë
    /*
     struct timeval
     {
         time_t tv_sec;  //Seconds.
         suseconds_t tv_usec;  //Microseconds.
     };
    */
     struct timeval tv2;
     long start, stop;
     float dis;

     digitalWrite(Trig, LOW);
     delayMicroseconds(2);

     digitalWrite(Trig, HIGH);
     delayMicroseconds(10);      //·¢³ö³¬Éù²¨Âö³å
     digitalWrite(Trig, LOW);

     while(!(digitalRead(Echo) == 1));
     gettimeofday(&tv1, NULL);           //»ñÈ¡µ±Ç°Ê±¼ä ¿ªÊ¼½ÓÊÕµ½·µ»ØÐÅºÅµÄÊ±ºò

     while(!(digitalRead(Echo) == 0));
     gettimeofday(&tv2, NULL);           //»ñÈ¡µ±Ç°Ê±¼ä  ×îºó½ÓÊÕµ½·µ»ØÐÅºÅµÄÊ±ºò
     /*
     int gettimeofday(struct timeval *tv, struct timezone *tz);
     The functions gettimeofday() and settimeofday() can get and set the time as well as a timezone.
     The use of the timezone structure is obsolete; the tz argument should normally be specified as NULL.
     */
     start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //Î¢Ãë¼¶µÄÊ±¼ä
     stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

     dis = (float)(stop - start) / 1000000 * 34000 / 2;  //¼ÆËãÊ±¼ä²îÇó³ö¾àÀë

     return dis;
 }
void errorTrap(void)
{
    while(1);
}
void setupCamera(int width, int height)
{
	// Open the camera device for image capture, set the dimensions of the image
	if (!cap.isOpened())
	{
		std::cerr << "ERROR: Unable to open the camera" << std::endl;
		errorTrap();
	}
	cap.set(CAP_PROP_FRAME_WIDTH, width);
	cap.set(CAP_PROP_FRAME_HEIGHT, height);
	//cameraFlag = 1;
}
void RecognizeColor()
{
        if (numred>2)
        {
            numrec=numred,sumrec=sumred;
            leftMotorBaseSpeed=26;
            rightMotorBaseSpeed=22;
            cout <<"RedRedRed"<<endl;
        }
        else if (numyellow>2)
        {
            numrec=numyellow,sumrec=sumyellow;
            cout <<"YellowYellowYellow"<<endl;
        }
        else if (numblue>2)
        {
            numrec=numblue,sumrec=sumblue;
            cout <<"BlueBlueBlue"<<endl;
        }
        else if (numgreen>2)
        {
            numrec=numgreen,sumrec=sumgreen;
            leftMotorBaseSpeed=28;
            rightMotorBaseSpeed=32;
            cout<<"GreenGreenGreen"<<endl;
        }
        else
        {
            numrec=numblack,sumrec=sumblack;
            cout <<"BlackandWhile"<<endl;
        }

        linedist =(float) (sumrec/numrec)-157; // error can be positive or negative
        cout << "num is: " << numrec <<endl;

}
Mat captureFrame(void)
{
    Mat frame;
	cap >> frame;
	if(!frame.data)
	{
		std::cout<< "ERROR: Unable to read camera image" << std::endl;
		errorTrap();
	}
	return frame;
}
void setup()
{if(wiringPiSetupGpio() == -1)
        {
         printf("setup wiringPi failed !");
         exit(EXIT_FAILURE);
        }
    pinMode(Echo, INPUT);
    pinMode(Trig, OUTPUT);
    pinMode(servo, OUTPUT);

    if((lcd = lcdInit(2,16,4,LCD_RS,LCD_E,LCD_D4,LCD_D5,LCD_D6,LCD_D7,0,0,0,0)))
    {cout <<"fail.";}
    // lcdPosition(lcd,0,0);
    // float dis;
    // dis = disMeasure();
    // lcdPrintf(lcd,"%0.2f",dis);
    robot=serialOpen("/dev/ttyAMA0",57600);
    	// Variable to store the camera device
    setupCamera(320, 240);
}
float PID(float lineDist)
{
     if(numrec<11){

     return output;
     cout << "Output: "<<output<<endl;
    }
    else{
  errorOld = ERROR;        // Save the old error for differential component
  ERROR = lineDist;  // Calculate the error in position
  errorSum += ERROR;
  float proportional = ERROR * Kp;  // Calculate the components of the PID

  float integral = errorSum * Ki/100;

  float differential = (ERROR - errorOld) * Kd;

  float output = proportional + integral + differential;  // Calculate the result
    cout <<"Output: "<<output<<endl;
  return output;}
}
void MotorSpeed(){

  leftMotorSpeed = leftMotorBaseSpeed + output;     // Calculate the modified motor speed
  rightMotorSpeed = rightMotorBaseSpeed - output;

  if(leftMotorSpeed >= 0 ) {leftMotorSpeed = (leftMotorSpeed>max_speed) ? max_speed:leftMotorSpeed;}
     else{leftMotorSpeed = (leftMotorSpeed<min_speed) ? min_speed:leftMotorSpeed;}
  if(rightMotorSpeed >= 0 ) {rightMotorSpeed = (rightMotorSpeed>max_speed) ? max_speed:rightMotorSpeed;}
     else{rightMotorSpeed = (rightMotorSpeed<min_speed) ? min_speed:rightMotorSpeed;}

   cout <<"Motorspeed:"<<leftMotorSpeed<<"\t"<<rightMotorSpeed<<endl;

//     Serial.print(leftMotorSpeed);Serial.print("\t");
//     Serial.println(rightMotorSpeed);
}
void controlvehicle(){

    char leftspeed[10];
    char rightspeed[10];
    char rightlastspeed[10];
    if(numrec>70 && linedist > 0){
      serialPrintf(robot,"#Baffrr099,099,099,099");
      if(purplenumber==5||purplenumber==6||purplenumber==13||purplenumber==14)  delayMicroseconds(200000);
      else if(purplenumber==3||purplenumber==11||purplenumber==7||purplenumber==15) delayMicroseconds(25000);
      else  delayMicroseconds(10000);
      cout<<"youzhuan"<<endl;
    }

    else if( numrec>70 && linedist < 0){
      serialPrintf(robot,"#Barrff099,099,099,099");
      if(purplenumber==2||purplenumber==10)      delayMicroseconds(200000);
      else delayMicroseconds(10000);
      cout<<"zuozhuan"<<endl;
    }


    else{
    serialPrintf(robot,"#Ba");
    serialPrintf(robot,(leftMotorSpeed>0)?"ff":"rr");
    serialPrintf(robot,(rightMotorSpeed>0)?"ff":"rr");

    sprintf(leftspeed, "%03d,",abs(leftMotorSpeed));
    sprintf(rightspeed, "%03d,",abs(rightMotorSpeed));
    sprintf(rightlastspeed, "%03d",abs(rightMotorSpeed));

    serialPrintf(robot,leftspeed);
    serialPrintf(robot,leftspeed);
    serialPrintf(robot,rightspeed);
    serialPrintf(robot,rightlastspeed);

    }
  }


float compareImages(Mat cameraImage, Mat librarySymbol)
{
    // if(((float)librarySymbol.cols*(float)librarySymbol.rows)==0)
    // {
    // cout<< "==0"<<endl;
    // float matchpercent=0;
    // return matchpercent;
    // }
    float matchPercent = 100 - (100/((float)librarySymbol.cols*(float)librarySymbol.rows) * (2*(float)countNonZero(librarySymbol^cameraImage))); // An incorrect pixel has double weighting
    return matchPercent;
}

void functionmatch()
{
    resizeCamera(640,480);
    float match[12]={1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0};

    float matchmax=0;
    int matchindex=0;
    int counterloop=0;
    while((match[matchindex]<67)&&(counterloop<40)){
    ++counterloop;
//    for(int a=0;a<100;a++)
//    {
    //counter++;
    Mat frame=captureFrame();
    Mat frameHSV;
    //Mat framemorph;
    Mat frametransform(480,640,CV_32FC1, Scalar(255));
    cvtColor(frame,frameHSV,COLOR_BGR2HSV);
    vector<Mat> channels; // Array for channels
    split(frameHSV, channels); // Split the HSV into separate channels
    equalizeHist(channels[2], channels[2]); // Equalise the V
    merge(channels, frameHSV);
    inRange(frameHSV,Scalar(159,80,35),Scalar(169,255,255),frameHSV);//169

//        Mat kernel=getStructuringElement(MORPH_RECT,Size(3,3));
//        morphologyEx(frameHSV,frameHSV,MORPH_OPEN,kernel);
        vector<vector<Point>> contours;
        vector<Vec4i>hierarchy;
        findContours(frameHSV, contours,hierarchy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point(0,0));
        if(contours.size()>0)
        {
        vector<int> area;

        int maxindex=0,maxarea=0;

        for(int i=0;i<contours.size();i++)
        {
        area.push_back(abs(contourArea(contours[i])));

        if(area[i]>maxarea)
        {
            maxarea=area[i];
            maxindex=i;
        }
        }

        vector<vector<Point>> approxedcontours(contours.size());
        for(int i=0;i<contours.size();++i)
        {
        approxPolyDP(contours[i],approxedcontours[i],20,true);

        }

        frametransform=transformPerspective(approxedcontours[maxindex],frameHSV,640,480);

        imshow("transform",frametransform);

        Mat symbolleft=imread("left.jpg");
        if(symbolleft.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbolleft,symbolleft,COLOR_BGR2HSV);
        inRange(symbolleft,Scalar(0,0,221),Scalar(180,30,255),symbolleft);

        Mat symbolright=imread("right.jpg");
        if(symbolright.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbolright,symbolright,COLOR_BGR2HSV);
        inRange(symbolright,Scalar(0,0,221),Scalar(180,30,255),symbolright);

        Mat symboltraffic=imread("traffic.jpg");
        if(symboltraffic.empty())
        {cout <<"Fail";return ;}
        cvtColor(symboltraffic,symboltraffic,COLOR_BGR2HSV);
        inRange(symboltraffic,Scalar(0,0,221),Scalar(180,30,255),symboltraffic);

        Mat symbolball=imread("ball.jpg");
        if(symbolball.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbolball,symbolball,COLOR_BGR2HSV);
        inRange(symbolball,Scalar(0,0,221),Scalar(180,30,255),symbolball);

        Mat symboldistacne=imread("distance.jpg");
        if(symboldistacne.empty())
        {cout <<"Fail";return ;}
        cvtColor(symboldistacne,symboldistacne,COLOR_BGR2HSV);
        inRange(symboldistacne,Scalar(0,0,221),Scalar(180,30,255),symboldistacne);

        Mat symbol221=imread("221shape.jpg");
        if(symbol221.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbol221,symbol221,COLOR_BGR2HSV);
        inRange(symbol221,Scalar(0,0,221),Scalar(180,30,255),symbol221);

        Mat symbol222=imread("222shape.jpg");
        if(symbol222.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbol222,symbol222,COLOR_BGR2HSV);
        inRange(symbol222,Scalar(0,0,221),Scalar(180,30,255),symbol222);

        Mat symbol233=imread("233shape.jpg");
        if(symbol233.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbol233,symbol233,COLOR_BGR2HSV);
        inRange(symbol233,Scalar(0,0,221),Scalar(180,30,255),symbol233);

        Mat symbolred=imread("red.jpg");
        if(symbolred.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbolred,symbolred,COLOR_BGR2HSV);
        inRange(symbolred,Scalar(0,0,221),Scalar(180,30,255),symbolred);

        Mat symbolblue=imread("blue.jpg");
        if(symbolblue.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbolblue,symbolblue,COLOR_BGR2HSV);
        inRange(symbolblue,Scalar(0,0,221),Scalar(180,30,255),symbolblue);

        Mat symbolgreen=imread("green.jpg");
        if(symbolgreen.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbolgreen,symbolgreen,COLOR_BGR2HSV);
        inRange(symbolgreen,Scalar(0,0,221),Scalar(180,30,255),symbolgreen);

        Mat symbolyellow=imread("yellow.jpg");
        if(symbolyellow.empty())
        {cout <<"Fail";return ;}
        cvtColor(symbolyellow,symbolyellow,COLOR_BGR2HSV);
        inRange(symbolyellow,Scalar(0,0,221),Scalar(180,30,255),symbolyellow);

        match[0]=compareImages(frametransform,symbolleft);
        match[1]=compareImages(frametransform,symbolright);
        match[2]=compareImages(frametransform,symboltraffic);
        match[3]=compareImages(frametransform,symbolball);
        match[4]=compareImages(frametransform,symboldistacne);
        match[5]=compareImages(frametransform,symbol221);
        match[6]=compareImages(frametransform,symbol222);
        match[7]=compareImages(frametransform,symbol233);
        match[8]=compareImages(frametransform,symbolred);
        match[9]=compareImages(frametransform,symbolblue);
        match[10]=compareImages(frametransform,symbolgreen);
        match[11]=compareImages(frametransform,symbolyellow);




        for(int i=0;i<12;++i)
        {
            if(match[i]>matchmax)
            {
                matchmax=match[i];
                matchindex=i;
            }
        }

        cout <<match[matchindex]<<endl;
//
//        char str[200];
//        sprintf(str,"%d.jpg",counter);
//        imwrite(str,frametransform);

        }//end if
        imshow("frame",frame);
        imshow("frameHSVrec",frameHSV);

        waitKey(33);
        }//end for camera
        if(match[matchindex]<65)
        {
            cout <<"no match"<<endl;
        }
        else {cout<< "success! Task is: "<<matchindex<<endl;
        if(matchindex==4)//distance
        {
            lcdClear(lcd);
            lcdPosition(lcd,0,0);
            float dis;
            dis = disMeasure();
            lcdPrintf(lcd,"%0.2f",dis);


        }

        else if(matchindex==5)//221
        {
            lcdClear(lcd);
            lcdPosition(lcd,0,0);
            lcdPuts(lcd,"C2 T2 R1");
        }

        else if(matchindex==6)//222
        {
            lcdClear(lcd);
            lcdPosition(lcd,0,0);
            lcdPuts(lcd,"C2 T2 R2");
        }

        else if(matchindex==7)//233
        {
            lcdClear(lcd);
            lcdPosition(lcd,0,0);
            lcdPuts(lcd,"C3 T3 R2");
        }

        else if(matchindex==8)//233
        {
            lcdClear(lcd);
            lcdPosition(lcd,0,0);
            lcdPuts(lcd,"Red");
        }

        else if(matchindex==9)//233
        {
            lcdClear(lcd);
            lcdPosition(lcd,0,0);
            lcdPuts(lcd,"Blue");
        }

        else if(matchindex==10)//233
        {
            lcdClear(lcd);
            lcdPosition(lcd,0,0);
            lcdPuts(lcd,"Green");
        }

        else if(matchindex==11)//233
        {
            lcdClear(lcd);
            lcdPosition(lcd,0,0);
            lcdPuts(lcd,"Yellow");
        }

        }
        resizeCamera(320,240);
}


void recpurple()
{
struct timeval tv2;
    gettimeofday(&tv2, NULL);
    stoppurple  = tv2.tv_sec * 1000000 + tv2.tv_usec;
    if((stoppurple-startpurple)>1500000)    purpleflag=1;

     if(numpurple>10&&purpleflag==1)
     {
        purplenumber++;
        cout<< "purplenumber: "<<purplenumber<<endl;
        serialPrintf(robot,"#Ha");

        for(int b=0;b<40;++b)
        {
        digitalWrite(servo, HIGH);
        delayMicroseconds(1333);
        digitalWrite(servo, LOW);
        delayMicroseconds(18667);
        }

       functionmatch();

        if(purplenumber==1||purplenumber==2||purplenumber==10||purplenumber==9||purplenumber==7||purplenumber==8||purplenumber==4||purplenumber==12||purplenumber==5||purplenumber==13||purplenumber==15||purplenumber==6||purplenumber==14)
        {
            for(int b=0;b<40;++b)
            {
            digitalWrite(servo, HIGH);
            delayMicroseconds(2000);//2333 15 degree
            digitalWrite(servo, LOW);
            delayMicroseconds(18000);
            }
        }

        else
        {
             for(int b=0;b<40;++b)
            {
            digitalWrite(servo, HIGH);
            delayMicroseconds(1833);//2111 35 degree
            digitalWrite(servo, LOW);
            delayMicroseconds(18167);
            }
        }

        struct timeval tv1;
        gettimeofday(&tv1, NULL);
        startpurple = tv1.tv_sec * 1000000 + tv1.tv_usec;

        purpleflag=0;
        Mat frameempty;
        for(int i=0;i<8;++i)
        {
        frameempty = captureFrame();
        }

        //serialPrintf(robot,"Baffff020,020,020,020");

        //delay(300);
     }

}


int main()
{
    setup();
    while(1)
    {
    numpurple=0;numblack=1;numred=1;numyellow=1;numblue=1;numgreen=1;sumred=0;sumyellow=0;sumblue=0;sumgreen=0;sumblack=0;

    Mat frame = captureFrame();
    Mat frameHSV;
    Mat framein;
    cvtColor(frame, frameHSV, COLOR_BGR2HSV);

    //see the balck line.
    inRange(frameHSV, Scalar(0, 0, 0), Scalar(180, 255, 46), framein);

        for(x = 0; x < frameHSV.cols; x++)
        {
			Scalar pixel = frameHSV.at<Vec3b>(140,x);//180
            if( (pixel[0]>=0 && pixel[0]<=180) && (pixel[1]>=0 && pixel[1]<=255) && (pixel[2]>=0 && pixel[2]<=46) )
            {
            numblack++;
            sumblack+=x;
            }
            else if( (pixel[0]>=162 && pixel[0]<=166) && (pixel[1]>=43 && pixel[1]<=255) && (pixel[2]>=46 && pixel[2]<=255) )
            {
            numpurple++;
            }
            else if( (pixel[0]>=173 && pixel[0]<=180) && (pixel[1]>=43 && pixel[1]<=255) && (pixel[2]>=46 && pixel[2]<=255) )
            {
            numred++;
            sumred+=x;
            }
            else if( (pixel[0]>=21 && pixel[0]<=24) && (pixel[1]>=136 && pixel[1]<=255) && (pixel[2]>=46 && pixel[2]<=255) )
            {
            numyellow++;
            sumyellow+=x;
            }
//            else if( (pixel[0]>=100 && pixel[0]<=133) && (pixel[1]>=43 && pixel[1]<=255) && (pixel[2]>=46 && pixel[2]<=255) )
//            {
//            numblue++;
//            sumblue+=x;
//            }
            else if( (pixel[0]>=35 && pixel[0]<=77) && (pixel[1]>=43 && pixel[1]<=255) && (pixel[2]>=46 && pixel[2]<=255) )
            {
            numgreen++;
            sumgreen+=x;
            }
        }
        leftMotorBaseSpeed=22;
        rightMotorBaseSpeed=22;

    RecognizeColor();//give color linedist
    output = PID(linedist);

    MotorSpeed();//set the motor speed and suturation
    controlvehicle();// Apply new speed and direction to each motor

    recpurple();

    imshow("frame",frame);
    imshow("frameHSV",frameHSV);
    imshow("framein",framein);

    int key = waitKey(33);   // Wait 1ms for a keypress (required to update windows
    if(key!=255) break;
    }//end while

    serialPrintf(robot,"#Ha");
    serialClose(robot);
    return 0;
}





